﻿namespace P06.BirthdayCelebrations
{
    public interface ICallableByName
    {
        string Name { get; }
    }
}
