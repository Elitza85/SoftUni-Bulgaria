﻿using System;

namespace P06.BirthdayCelebrations
{
    public interface IBirthable
    {
        DateTime BirthDate { get; }
    }
}
