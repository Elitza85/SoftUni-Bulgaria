﻿namespace P06.BirthdayCelebrations
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
