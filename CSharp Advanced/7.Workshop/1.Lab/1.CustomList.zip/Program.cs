﻿using System;

namespace Workshop
{
    class Program
    {
        static void Main(string[] args)
        {
            var list = new CustomList();
            var list2 = new CustomList(50);
        }
    }
}
