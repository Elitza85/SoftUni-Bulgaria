﻿using System;
using System.Linq;

namespace _1
{
    public class Program
    {
        static void Main(string[] args)
        {
            string[] firstInout = Console.ReadLine().Split();
            string[] secondInput = Console.ReadLine().Split();
            string[] thirdInput = Console.ReadLine().Split();

            string name = firstInout[0]+ " " +firstInout[1];
            string town = firstInout[2];

            string person = secondInput[0];
            int num = int.Parse(secondInput[1]);

            int myNum = int.Parse(thirdInput[0]);
            double myDouble = double.Parse(thirdInput[1]);

            Tuple<string, string> firstTuple = new Tuple<string, string>(name, town);
            
            Tuple<string, int> secondTuple = new Tuple<string, int>(person, num);
            
            Tuple<int, double> thirdTuple = new Tuple<int, double>(myNum, myDouble);

            Console.WriteLine(firstTuple.GetInfo());
            Console.WriteLine(secondTuple.GetInfo());
            Console.WriteLine(thirdTuple.GetInfo());
        }
    }
}
