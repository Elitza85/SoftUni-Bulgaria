﻿using System;

namespace _1
{
    class Program
    {
        static void Main(string[] args)
        {
            int count = int.Parse(Console.ReadLine());
            Box<string> myBox= new Box<string>();

            for (int i = 0; i < count; i++)
            {
                string input = Console.ReadLine();
                myBox.Add(input);
            }

            Console.WriteLine(myBox.ToString());
        }
    }
}
