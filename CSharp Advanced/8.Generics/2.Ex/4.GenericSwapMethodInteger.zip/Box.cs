﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _1
{
    public class Box<T>
    {
        private List<T> boxCollection;
        public Box()
        {
            this.boxCollection = new List<T>();
        }

        public void Add(T item)
        {
            this.boxCollection.Add(item);
        }

        public void Swap(int x, int y)
        {
            T tempValue = this.boxCollection[x];
            this.boxCollection[x] = this.boxCollection[y];
            this.boxCollection[y] = tempValue;
        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            foreach (var item in boxCollection)
            {
                sb.AppendLine($"{item.GetType().FullName}: {item}");
            }
            return sb.ToString();
        }
    }
}
