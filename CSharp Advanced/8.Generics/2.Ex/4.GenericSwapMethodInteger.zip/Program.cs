﻿using System;
using System.Linq;

namespace _1
{
    class Program
    {
        static void Main(string[] args)
        {
            int count = int.Parse(Console.ReadLine());
            Box<int> myBox= new Box<int>();

            for (int i = 0; i < count; i++)
            {
                int input = int.Parse(Console.ReadLine());
                myBox.Add(input);
            }
            int[] indexes = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToArray();
            int firstInd = indexes[0];
            int secondInd = indexes[1];

            myBox.Swap(firstInd, secondInd);

            Console.WriteLine(myBox.ToString());
        }
    }
}
