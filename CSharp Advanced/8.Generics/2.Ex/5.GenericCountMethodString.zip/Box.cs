﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _1
{
    public class Box<T> 
        where T :IComparable<T>
    {
        private List<T> boxCollection;
        public Box()
        {
            this.boxCollection = new List<T>();
        }

        public int Count { get; private set; }

        public void Add(T item)
        {
            this.boxCollection.Add(item);
        }
        public void CompareMethod(T item)
        {
            foreach (var currentItem in this.boxCollection)
            {
                if (currentItem.CompareTo(item)>0)
                {
                    Count++;
                }
            }
        }


        public void Swap(int x, int y)
        {
            T tempValue = this.boxCollection[x];
            this.boxCollection[x] = this.boxCollection[y];
            this.boxCollection[y] = tempValue;
        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            foreach (var item in boxCollection)
            {
                sb.AppendLine($"{item.GetType().FullName}: {item}");
            }
            return sb.ToString();
        }
    }
}
