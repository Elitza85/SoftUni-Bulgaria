﻿using System;

namespace _1
{
    class Program
    {
        static void Main(string[] args)
        {
            int count = int.Parse(Console.ReadLine());
            Box<int> myBox= new Box<int>();

            for (int i = 0; i < count; i++)
            {
                int input = int.Parse(Console.ReadLine());
                myBox.Add(input);
            }

            Console.WriteLine(myBox.ToString());
        }
    }
}
