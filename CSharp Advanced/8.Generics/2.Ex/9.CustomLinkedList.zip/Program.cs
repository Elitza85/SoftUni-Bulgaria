﻿using System;

namespace DoublyLinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            var doubleList = new DoublyLinkedList<string>();

            
        }
    }
}
