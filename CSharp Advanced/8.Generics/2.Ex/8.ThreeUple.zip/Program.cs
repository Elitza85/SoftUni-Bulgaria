﻿using System;
using System.Linq;

namespace _1
{
    public class Program
    {
        static void Main(string[] args)
        {
            string[] firstInput = Console.ReadLine().Split();
            string[] secondInput = Console.ReadLine().Split();
            string[] thirdInput = Console.ReadLine().Split();

            string name = firstInput[0]+ " " +firstInput[1];
            string address = firstInput[2];
            string town = string.Empty;
            if (firstInput.Length == 4)
            {
                town = firstInput[3];
            }
            else if (firstInput.Length == 5)
            {
                town = firstInput[3] + " " + firstInput[4];
            }

            string person = secondInput[0];
            int literBeer = int.Parse(secondInput[1]);
            string status = secondInput[2];

            string myName = thirdInput[0];
            double myAccount = double.Parse(thirdInput[1]);
            string bank = thirdInput[2];
            

            Tuple<string, string, string> firstTuple = new Tuple<string,string, string>(name,address, town);
            
            Tuple<string, int, bool> secondTuple = new 
                Tuple<string, int, bool>(person, literBeer, status=="drunk" ? true: false);
            
            Tuple<string, double, string> thirdTuple = new 
                Tuple<string, double, string>(myName, myAccount, bank);

            Console.WriteLine(firstTuple);
            Console.WriteLine(secondTuple);
            Console.WriteLine(thirdTuple);
        }
    }
}
