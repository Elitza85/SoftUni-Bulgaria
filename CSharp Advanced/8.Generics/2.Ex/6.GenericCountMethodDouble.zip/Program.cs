﻿using System;
using System.Linq;

namespace _1
{
    class Program
    {
        static void Main(string[] args)
        {
            int count = int.Parse(Console.ReadLine());
            Box<double> myBox= new Box<double>();

            for (int i = 0; i < count; i++)
            {
                double input = double.Parse(Console.ReadLine());
                myBox.Add(input);
            }
            double doubleToCompare = double.Parse(Console.ReadLine());

            myBox.CompareMethod(doubleToCompare);

            Console.WriteLine(myBox.Count);
        }
    }
}
