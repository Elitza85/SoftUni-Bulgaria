﻿using System;

namespace GenericScale
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int one = 2;
            int two = 2;
            var scale = new EqualityScale<int>(one, two);
            Console.WriteLine(scale.AreEqual());
        }
    }
}
