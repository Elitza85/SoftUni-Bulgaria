﻿using System;

namespace GenericArrayCreator
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var strings= ArrayCreator.Create(10, "string");
        }
    }
}
