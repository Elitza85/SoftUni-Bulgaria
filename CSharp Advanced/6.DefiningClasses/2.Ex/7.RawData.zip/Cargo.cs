﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RawData
{
    public class Cargo
    {
        private int cargoWeight;
        private string cargoType;

        public Cargo(int weight,string type)
        {
            this.cargoWeight = weight;
            this.cargoType = type;
        }

        public string Type
        {
            get { return this.cargoType; }
            set { this.cargoType = value; }
        }
        public int Weight
        {
            get { return this.cargoWeight; }
            set { this.cargoWeight = value; }
        }
    }
}
