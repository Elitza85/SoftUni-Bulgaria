﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RawData
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int totalCars = int.Parse(Console.ReadLine());
            List<Car> cars = new List<Car>();


            for (int i = 0; i < totalCars; i++)
            {
                string[] currentCar = Console.ReadLine().Split();
                string model = currentCar[0];
                Engine engine = new Engine(int.Parse(currentCar[1]), int.Parse(currentCar[2]));
                Cargo cargo = new Cargo(int.Parse(currentCar[3]), currentCar[4]);
                Tire[] tires = new Tire[4]
                {
                    new Tire(double.Parse(currentCar[5]),int.Parse(currentCar[6])),
                    new Tire(double.Parse(currentCar[7]),int.Parse(currentCar[8])),
                    new Tire(double.Parse(currentCar[9]),int.Parse(currentCar[10])),
                    new Tire(double.Parse(currentCar[11]),int.Parse(currentCar[12]))
                };
                Car currCar = new Car(model, engine, cargo, tires);
                cars.Add(currCar);
            }

            string command = Console.ReadLine();

            if (command == "fragile")
            {
                var sortedCars= cars
                .Where(x => x.Cargo.Type == command
                    && x.Tires.Any(t => t.Pressure < 1))
                    .ToList();
                foreach (var car in sortedCars)
                {
                    Console.WriteLine(car.Model);
                }
            }
            else if (command == "flamable")
            {
                cars.Where(x => x.Cargo.Type == command && x.Engine.Power > 250).Select(x => x.Model)
                        .ToList().ForEach(Console.WriteLine);
            }
        }
    }
}
