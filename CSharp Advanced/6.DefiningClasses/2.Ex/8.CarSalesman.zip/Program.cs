﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CarSalesman
{
    public class Program
    {
        static void Main(string[] args)
        {
            int count = int.Parse(Console.ReadLine());

            List<Engine> engines = new List<Engine>();
            for (int i = 0; i < count; i++)
            {
                string[] engineTokens = Console.ReadLine().Split();

                string engineModel = engineTokens[0];
                string enginePower = engineTokens[1];

                if(engineTokens.Length==2)
                {
                    engines.Add(new Engine(engineModel, enginePower));
                }

                else if(engineTokens.Length==3)
                {
                    int displacement = 0;
                    bool isDisplacement = int.TryParse(engineTokens[2], out displacement);
                    if(isDisplacement)
                    {
                        engines.Add(new Engine(engineModel, enginePower, displacement));
                    }
                    else
                    {
                        string engineEfficiency = engineTokens[2];
                        engines.Add(new Engine(engineModel, enginePower, engineEfficiency));
                    }
                }

                else if(engineTokens.Length==4)
                {
                    int displacement = int.Parse(engineTokens[2]);
                    string engineEfficiency = engineTokens[3];
                    Engine currEngine =
                    new Engine(engineModel, enginePower, displacement, engineEfficiency);
                    engines.Add(currEngine);
                }
                
            }

            int newCount = int.Parse(Console.ReadLine());
            List<Car> cars = new List<Car>(); ;
            for (int j = 0; j < newCount; j++)
            {
                string[] carTokens = Console.ReadLine().Split();
                string carModel = carTokens[0];
                string engineModel = carTokens[1];
                Engine engine = new Engine(null, null);

                foreach (Engine eng in engines)
                {
                    if(eng.EngineModel==engineModel)
                    {
                        engine = eng;
                    }
                }

                if (carTokens.Length == 2)
                {
                    cars.Add(new Car(carModel, engine));
                }

                else if(carTokens.Length==3)
                {
                    int weight = 0;
                    bool isWeight = int.TryParse(carTokens[2], out weight);
                    if (isWeight)
                    {
                        cars.Add(new Car(carModel, engine, weight));
                    }
                    else
                    {
                        string colour = carTokens[2];
                        cars.Add(new Car(carModel, engine, colour));
                    }
                }
                
                else if(carTokens.Length==4)
                {
                    int weight = int.Parse(carTokens[2]);
                    string colour = carTokens[3];
                    cars.Add(new Car(carModel, engine, weight, colour));
                }
            }

            foreach (var car in cars)
            {
                Console.WriteLine(car.ToString());
            }
        }
    }
}
