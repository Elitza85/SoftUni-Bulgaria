﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarSalesman
{
    public class Engine
    {
        private string engineModel;
        private string power;
        private int displacement;
        private string efficiency;

        public Engine(string engineModel, string power)
        {
            this.engineModel = engineModel;
            this.power = power;
            this.displacement = 0;
            this.efficiency = "n/a";
        }

        public Engine(string engineModel, string power, int displacement)
            :this(engineModel,power)
        {
            this.displacement = displacement;
        }

        public Engine(string engineModel, string power, string efficiency)
            :this(engineModel, power)
        {
            this.efficiency = efficiency;
        }

        public Engine(string engineModel, string power, int displacement, string efficiency)
            :this(engineModel,power)
        {
            this.displacement = displacement;
            this.efficiency = efficiency;
        }

        public string EngineModel
       {
           get { return this.engineModel; }
            set { this.engineModel = value; }
        }

        public override string ToString()
        {
            var result = $"{engineModel}:" +
                Environment.NewLine +
                $"    Power: {power}" +
                Environment.NewLine +
                $"{ (displacement == 0 ? "    Displacement: n/a" : $"    Displacement: {displacement}")} " +
                Environment.NewLine +
                $"{(efficiency== null ? "    Efficiency: n/a" : $"    Efficiency: {efficiency}")}";
            return result;
        }
        
    }
}
