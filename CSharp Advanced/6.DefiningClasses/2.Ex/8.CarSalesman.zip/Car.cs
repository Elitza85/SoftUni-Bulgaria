﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarSalesman
{
    public class Car
    {
        private string model;
        private Engine engine;
        private int weight;
        private string colour;

        public Car(string model, Engine engine)
        {
            this.model = model;
            this.engine = engine;
            this.weight = 0;
            this.colour = "n/a";
        }

        public Car(string model, Engine engine, int weight)
            : this(model, engine)
        {
            this.weight = weight;
        }

        public Car(string model, Engine engine, string colour)
            : this(model, engine)
        {
            this.colour = colour;
        }

        public Car(string model, Engine engine, int weight, string colour)
            : this(model, engine)
        {
            this.weight = weight;
            this.colour = colour;
        }

        public override string ToString()
        {
            var result = $"{model}:" +
                Environment.NewLine +
                $"  {engine}" +
                Environment.NewLine +
                $"{(weight==0 ? "  Weight: n/a" : $"  Weight: {weight}")}" +
                Environment.NewLine +
                $"{(colour==null ? "  Color: n/a" : $"  Color: {colour}")}";

            return result;
        }

        
    } 
}
