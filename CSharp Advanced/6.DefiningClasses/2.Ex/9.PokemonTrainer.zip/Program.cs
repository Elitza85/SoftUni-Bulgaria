﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PokemonTrainer
{
    public class Program
    {
        static void Main(string[] args)
        {
            string line = string.Empty;
            List<Trainer> trainers = new List<Trainer>();

            while ((line=Console.ReadLine())!="Tournament")
            {
                string[] data = line.Split();
                string tName = data[0];
                string pName = data[1];
                string pElement = data[2];
                int pHealth = int.Parse(data[3]);
                int badges = 0;

                Pokemon newPokemon = new Pokemon(pName, pElement, pHealth);

                if(!trainers.Any(t=>t.Name==tName))
                {
                    trainers.Add(new Trainer(tName, badges, new List<Pokemon>()));
                }
                trainers.FirstOrDefault(x => x.Name == tName).ListOfPokemons.Add(newPokemon);
            }

            while ((line = Console.ReadLine()) != "End")
            {
                switch (line)
                {
                    case "Fire":
                        foreach (var trainer in trainers)
                        {
                            if (trainer.ListOfPokemons.Any(x => x.PElement == "Fire"))
                            {
                                trainer.Badges++;
                            }
                            else
                            {
                                foreach (var pokemon in trainer.ListOfPokemons)
                                {
                                    pokemon.PHealth -= 10;
                                    
                                }
                                trainer.ListOfPokemons.RemoveAll(x => x.PHealth <= 0);
                            }
                        }
                        break;
                    case "Water":
                        foreach (var trainer in trainers)
                        {
                            if (trainer.ListOfPokemons.Any(x => x.PElement == "Water"))
                            {
                                trainer.Badges++;
                            }
                            else
                            {
                                foreach (var pokemon in trainer.ListOfPokemons)
                                {
                                    pokemon.PHealth -= 10;
                                    
                                }
                                trainer.ListOfPokemons.RemoveAll(x => x.PHealth <= 0);
                            }
                        }
                        break;
                    case "Electricity":
                        foreach (var trainer in trainers)
                        {
                            if (trainer.ListOfPokemons.Any(x => x.PElement == "Electricity"))
                            {
                                trainer.Badges++;
                            }
                            else
                            {
                                foreach (var pokemon in trainer.ListOfPokemons)
                                {
                                    pokemon.PHealth -= 10;
                                    
                                }
                                trainer.ListOfPokemons.RemoveAll(x => x.PHealth <= 0);
                            }
                        }
                        break;
                        
                }
            }
            foreach (var trainer in trainers.OrderByDescending(x => x.Badges))
            {
                Console.WriteLine($"{trainer.Name} {trainer.Badges} {trainer.ListOfPokemons.Count}");
            }
        }
    }
}
