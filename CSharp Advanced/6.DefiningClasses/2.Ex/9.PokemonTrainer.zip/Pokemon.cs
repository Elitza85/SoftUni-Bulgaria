﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PokemonTrainer
{
    public class Pokemon
    {
        public Pokemon(string pName, string pElement, int pHealth)
        {
            this.PName = pName;
            this.PElement = pElement;
            this.PHealth = pHealth;
        }
        public string PName { get; set; }

        public string PElement { get; set; }

        public int PHealth { get; set; }
    }
}
