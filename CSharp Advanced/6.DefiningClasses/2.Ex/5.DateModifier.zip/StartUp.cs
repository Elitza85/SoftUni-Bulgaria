﻿

namespace DateModifier
{
    using System;
    public class StartUp
    {
        static void Main(string[] args)
        {
            string dateOne = Console.ReadLine();
            string dateTwo = Console.ReadLine();

            Console.WriteLine(DateModifier.GetDays(dateOne,dateTwo));
        }
    }
}
