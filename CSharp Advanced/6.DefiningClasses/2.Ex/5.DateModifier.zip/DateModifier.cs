﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace DateModifier
{
    public static class DateModifier
    {
        public static double GetDays(string dayOne, string dayTwo)
        {
            var firstDate = DateTime.ParseExact(dayOne, "yyyy MM dd", CultureInfo.InvariantCulture);
            var secondDate = DateTime.ParseExact(dayTwo, "yyyy MM dd", CultureInfo.InvariantCulture);

            if(firstDate>secondDate)
            {
                return (firstDate-secondDate).Days;
            }
            return (secondDate - firstDate).Days;
        }
    }
}
