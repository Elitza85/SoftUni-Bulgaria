﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string command = string.Empty;
            List<Tire[]> tiresList = new List<Tire[]>();
            List<Engine> enginesList = new List<Engine>();

            while ((command=Console.ReadLine())!="No more tires")
            {
                string[] tireData = command.Split();
                Tire[] tiresSet = new Tire[4];
                int position = 0;
                for (int i = 0; i < tireData.Length; i+=2)
                {
                    int tireYear = int.Parse(tireData[i]);
                    double tirePressure = double.Parse(tireData[i+1]);
                    Tire singleTire = new Tire(tireYear, tirePressure);

                    tiresSet[position] = singleTire;
                    position++;
                }
                tiresList.Add(tiresSet);
            }

            while ((command=Console.ReadLine())!="Engines done")
            {
                string[] engineData = command.Split();
                int horsePower= int.Parse(engineData[0]);
                double cubicCapacity = double.Parse(engineData[1]);
                Engine currEngine = new Engine(horsePower, cubicCapacity);
                enginesList.Add(currEngine);
            }

            List<Car> carsList = new List<Car>();
            while ((command=Console.ReadLine())!="Show special")
            {
                string[] carData = command.Split();
                string make = carData[0];
                string model = carData[1];
                int year = int.Parse(carData[2]);
                double fuelQuantity = double.Parse(carData[3]);
                double fuelConsumption = double.Parse(carData[4]);
                int engIndex = int.Parse(carData[5]);
                int tiresIndex = int.Parse(carData[6]);

                Car newCar = new Car(make, model, year, fuelQuantity, 
                    fuelConsumption, enginesList[engIndex], tiresList[tiresIndex]);
                carsList.Add(newCar);
            }
            

            foreach (var car in carsList
                .Where(x=>x.Year>=2017)
                .Where(y=>y.Engine.HorsePower>330)
                .Where(t=>t.Tires.Select(p=>p.Pressure).Sum()>=9)
                .Where(t=>t.Tires.Select(p=>p.Pressure).Sum()<=10))
            {
                car.DriveSpecialCars(20);
                Console.WriteLine(car.GetSpecialCarInfo()); 
            }
        }
    }
}
